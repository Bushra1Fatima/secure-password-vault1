import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from cryptography.fernet import Fernet
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = 'your-secret-key'  # Change this in production

DATABASE = 'database.db'

# Load encryption key from environment variable
key = os.environ.get('ENCRYPTION_KEY')
if not key:
    raise RuntimeError("❌ ENCRYPTION_KEY is not set. Please add it in the environment variables.")
else:
    key = key.encode()

fernet = Fernet(key)

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with app.app_context():
        db = get_db()
        with open('schema.sql', 'r') as f:
            db.executescript(f.read())
        db.commit()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email'].lower()
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords don't match.", 'error')
            return redirect(url_for('signup'))

        hashed_pw = generate_password_hash(password)

        try:
            db = get_db()
            db.execute('INSERT INTO users (email, password) VALUES (?, ?)', (email, hashed_pw))
            db.commit()
            flash('Account created! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Email already registered.', 'error')
            return redirect(url_for('signup'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].lower()
        password = request.form['password']

        db = get_db()
        user = db.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['email'] = user['email']
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password.', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        flash('Please log in to continue.', 'error')
        return redirect(url_for('login'))

    db = get_db()
    passwords = db.execute('SELECT site, username, password FROM passwords WHERE user_id = ?', 
                           (session['user_id'],)).fetchall()

    decrypted_passwords = []
    for pw in passwords:
        try:
            decrypted_pw = fernet.decrypt(pw['password'].encode()).decode()
        except Exception:
            decrypted_pw = "[decryption error]"
        decrypted_passwords.append({
            'site': pw['site'],
            'username': pw['username'],
            'password': decrypted_pw
        })

    return render_template('dashboard.html', user=session['email'], passwords=decrypted_passwords)

@app.route('/add_password', methods=['POST'])
def add_password():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    site = request.form['site']
    username = request.form['username']
    password = request.form['password']

    encrypted_password = fernet.encrypt(password.encode()).decode()

    db = get_db()
    db.execute('INSERT INTO passwords (user_id, site, username, password) VALUES (?, ?, ?, ?)', 
               (session['user_id'], site, username, encrypted_password))
    db.commit()

    flash('Password saved!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/delete_password', methods=['POST'])
def delete_password():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    site = request.form['site']
    username = request.form['username']

    db = get_db()
    db.execute(
        'DELETE FROM passwords WHERE user_id = ? AND site = ? AND username = ?',
        (session['user_id'], site, username)
    )
    db.commit()

    flash('Password deleted successfully.', 'success')
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('home'))

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 3000))
    app.run(host='0.0.0.0', port=port)
